module TripsHelper
end
