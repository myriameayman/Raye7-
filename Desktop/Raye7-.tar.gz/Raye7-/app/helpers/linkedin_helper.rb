module LinkedinHelper
end
