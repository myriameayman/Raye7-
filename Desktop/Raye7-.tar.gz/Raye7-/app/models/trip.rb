class Trip < ActiveRecord::Base
attr_accessible :request_id, :user_id  	
end