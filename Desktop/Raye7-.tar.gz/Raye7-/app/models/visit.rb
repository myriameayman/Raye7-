class Visit < ActiveRecord::Base
 	 attr_accessible :place_id, :user_id
end
