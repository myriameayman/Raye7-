require 'test_helper'

class LinkedinOauthSettingTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
