require 'test_helper'

class BasicProfileTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
