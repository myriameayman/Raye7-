require 'test_helper'

class LinkedinHelperTest < ActionView::TestCase
end
