require 'test_helper'

class PlacesHelperTest < ActionView::TestCase
end
