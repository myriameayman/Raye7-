require 'test_helper'

class TwitterHelperTest < ActionView::TestCase
end
