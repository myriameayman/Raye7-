require 'test_helper'

class RequestsHelperTest < ActionView::TestCase
end
