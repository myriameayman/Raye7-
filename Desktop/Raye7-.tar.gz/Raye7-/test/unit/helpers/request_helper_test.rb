require 'test_helper'

class RequestHelperTest < ActionView::TestCase
end
