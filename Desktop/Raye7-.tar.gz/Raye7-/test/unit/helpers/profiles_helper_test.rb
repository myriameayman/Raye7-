require 'test_helper'

class ProfilesHelperTest < ActionView::TestCase
end
