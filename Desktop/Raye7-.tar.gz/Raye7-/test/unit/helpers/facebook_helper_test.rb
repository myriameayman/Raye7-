require 'test_helper'

class FacebookHelperTest < ActionView::TestCase
end
