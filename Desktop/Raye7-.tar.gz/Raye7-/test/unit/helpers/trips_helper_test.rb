require 'test_helper'

class TripsHelperTest < ActionView::TestCase
end
