require 'test_helper'

class CirclesHelperTest < ActionView::TestCase
end
