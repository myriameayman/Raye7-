require 'test_helper'

class TwitterOauthSettingTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
