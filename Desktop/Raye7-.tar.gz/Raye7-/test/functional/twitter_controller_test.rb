require 'test_helper'

class TwitterControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
