# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
RsgLinkedinGem::Application.config.secret_token = '4fc6f27689c6c0fad30eb57cef17b3c77d498079566c492feba93fe0a60c4353844e3305d553528d31358322deee77bde49c2f4167065f044cbdcb6ee8d3ff28'
