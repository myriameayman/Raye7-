require 'test_helper'

class CategoryArticleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
