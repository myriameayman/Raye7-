class AddAttributeTocategory < ActiveRecord::Migration
  def change
  end
end
