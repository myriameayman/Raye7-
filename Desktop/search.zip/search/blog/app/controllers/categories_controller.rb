class CategoriesController < ApplicationController

end 