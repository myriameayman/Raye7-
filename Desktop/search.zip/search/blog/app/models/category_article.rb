class CategoryArticle < ActiveRecord::Base
end
