class Reply < ActiveRecord::Base

belongs_to :comment 

end
